**11-13-18** <br />
**Tasks to Complete Application Development Project** <br />


    1. Install Pygame onto my computer. - Done  
    2. Run game as a test. - Done  
    3. Initial review of code to familiarize myself. - Done  
    4. Change gap space to make it easier on the eyes. - Done  
    5. Find and download new images in line with Christmas theme. - Done  
    6. Learn more about push/pull. In progress  
    7. Change background color. - Done
    8. Update title to reflect new Christmas theme. - Done
    9. Insert pop-up window with directions after clicking a "help" icon.  
    9. Change reveal speed of icons to a faster pace.  
    10. Insert new images. - Done
    11. Test game.  
    12. Any new ideas?  
    13. Inserted a timer. -Done
    
    

