# -Matching-Game--Jennifer-
I have found a simple matching game at http://inventwithpython.com/pygame created by Al Sweigart entitled *Memory Puzzle*. My goal is to modify the orginal code to show Christmas colors and reveal fun holiday shapes, which is credited to http://iconka.com. 

